//
// Created by klara on 21.4.18.
//

#include "MZApi/Display.h"
#include "DisplayUtils/Colour.h"
#include "DisplayUtils/font_rom8x16.h"
#include "Misc/IOTools.h"

int main(int argc, char** argv) {
    // create the lightUnits
    std::vector<LightUnit> lightUnits = {};
    char tmp_string[16];
    for (int i = 0; i < 28; ++i) {
        sprintf(tmp_string, "LightUnit #%d", i + 1);
        lightUnits.push_back(LightUnit(tmp_string));
        sprintf(tmp_string, "icons/%d.ppm", (i + 1)%7);
        IOTools::loadImage16x16(tmp_string, lightUnits[i].image);
    }

    char rgbDelta[3] = {0, 0, 0};
    bool knobsPressed[3] = {1, 0, 0};

    Display display = Display(Colour::WHITE, Colour::BLACK, Colour::LIME, font_rom8x16, lightUnits);
    display.redraw();
}