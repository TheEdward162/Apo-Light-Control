#include "Engine.h"

int main(int argc, char** argv) {
	return Engine::run(argc, argv);
}